import NumStability.Algorithms.HighamChapter15BoydSourceLocal

/-!
# R03 protected consumer — `NumStability.Algorithms.HighamChapter15BoydSourceLocal`

Integrator-owned consumer compiled unedited against the R03 worker tree;
its R0005 postimage is validated separately in a disposable checkout.
-/
