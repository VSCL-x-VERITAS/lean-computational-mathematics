import NumStability.Analysis.MatrixPowersGautschi

/-!
# R03 protected consumer — `NumStability.Analysis.MatrixPowersGautschi`

Integrator-owned consumer compiled unedited against the R03 worker tree;
its R0005 postimage is validated separately in a disposable checkout.
-/
