import NumStability.Analysis.ResolventFunctionalCalculus

/-!
# R03 protected consumer — `NumStability.Analysis.ResolventFunctionalCalculus`

Integrator-owned consumer compiled unedited against the R03 worker tree;
its R0005 postimage is validated separately in a disposable checkout.
-/
