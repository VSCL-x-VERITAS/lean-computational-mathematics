import NumStability.Source.Higham.Chapter14.Corollary06.SPD.SourceClosure

/-!
# R03 protected consumer — `NumStability.Source.Higham.Chapter14.Corollary06.SPD.SourceClosure`

Integrator-owned consumer compiled unedited against the R03 worker tree;
its R0005 postimage is validated separately in a disposable checkout.
-/
