import NumStability.Source.Higham.Chapter15.Section02.Boyd.EndpointTermination.RectangularTermination

/-!
# R03 protected consumer — `NumStability.Source.Higham.Chapter15.Section02.Boyd.EndpointTermination.RectangularTermination`

Integrator-owned consumer compiled unedited against the R03 worker tree;
its R0005 postimage is validated separately in a disposable checkout.
-/
