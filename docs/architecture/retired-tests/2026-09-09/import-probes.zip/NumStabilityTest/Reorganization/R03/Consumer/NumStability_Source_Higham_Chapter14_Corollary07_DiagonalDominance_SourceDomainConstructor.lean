import NumStability.Source.Higham.Chapter14.Corollary07.DiagonalDominance.SourceDomainConstructor

/-!
# R03 protected consumer — `NumStability.Source.Higham.Chapter14.Corollary07.DiagonalDominance.SourceDomainConstructor`

Integrator-owned consumer compiled unedited against the R03 worker tree;
its R0005 postimage is validated separately in a disposable checkout.
-/
