import NumStability.Source.Higham.Chapter21.Theorem04.SourceClosure.SourceClosure

/-!
# R05 protected consumer — `NumStability.Source.Higham.Chapter21.Theorem04.SourceClosure.SourceClosure`

Integrator-owned consumer compiled unedited against the R03 worker tree;
its R0006 postimage is validated separately in a disposable checkout.
-/
