import NumStability.Source.Higham.Chapter20.Theorem03.ZeroDeltaB

/-!
# R05 protected consumer — `NumStability.Source.Higham.Chapter20.Theorem03.ZeroDeltaB`

Integrator-owned consumer compiled unedited against the R03 worker tree;
its R0006 postimage is validated separately in a disposable checkout.
-/
