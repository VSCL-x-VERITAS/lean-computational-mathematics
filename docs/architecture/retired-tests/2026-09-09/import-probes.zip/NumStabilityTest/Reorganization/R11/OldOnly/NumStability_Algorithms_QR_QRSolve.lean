import NumStability.Algorithms.QR.QRSolve

/-!
# R11 historical-only test — `QRSolve`

Imports exactly the historical path `NumStability.Algorithms.QR.QRSolve`
and nothing else.

This owner is an already declaration-free compatibility wrapper whose
exact existing imports are retained unchanged; R11 only added module
documentation. It forwards to no R11 destination, so the obligation is
exactly that the documented wrapper still compiles and its retained
import still resolves.
-/
