import NumStability.Algorithms.Cholesky.Higham1014SourceSuccess

/-!
# NumStability.Algorithms.Cholesky.Higham1014SourceSuccess consumer test (R04)

Outside direct import consumer of an R04 historical path; compiles only if
the relocated surface remains reachable through retained compatibility
modules and aggregates.
-/
